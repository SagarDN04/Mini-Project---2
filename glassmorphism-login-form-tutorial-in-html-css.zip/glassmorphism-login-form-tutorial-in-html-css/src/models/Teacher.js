const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const teacherSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    password: {
        type: String,
        required: true
    },
    department: {
        type: String,
        required: true,
        trim: true
    },
    role: {
        type: String,
        default: 'teacher'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Hash password before saving
teacherSchema.pre('save', async function(next) {
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});

// Method to verify password
teacherSchema.methods.verifyPassword = async function(password) {
    return await bcrypt.compare(password, this.password);
};

const Teacher = mongoose.model('Teacher', teacherSchema);

// Create default teacher account if it doesn't exist
const createDefaultTeacher = async () => {
    try {
        const defaultTeacher = {
            name: 'Campus Sync Teacher',
            email: 'teacher@campussync.com',
            password: 'CampusSync2024!',
            department: 'Administration',
            role: 'teacher'
        };

        const existingTeacher = await Teacher.findOne({ email: defaultTeacher.email });
        if (!existingTeacher) {
            await Teacher.create(defaultTeacher);
            console.log('Default teacher account created successfully');
        }
    } catch (error) {
        console.error('Error creating default teacher account:', error);
    }
};

// Execute the creation of default teacher
createDefaultTeacher();

module.exports = Teacher; 