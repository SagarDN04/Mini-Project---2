const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    prn: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true
    },
    name: {
        type: String,
        required: true,
        trim: true
    },
    department: {
        type: String,
        required: true,
        trim: true,
        enum: [
            'CSE',
            'AIML',
            'DS',
            'MECHANICAL',
            'ENTC',
            'ELECTRICAL',
            'BIOTECH',
            'CIVIL',
            'ENVIRONMENT'
        ]
    },
    graduationYear: {
        type: Number,
        required: true,
        min: 2024,
        max: 2030
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Update timestamp on save
studentSchema.pre('save', function(next) {
    this.updatedAt = new Date();
    next();
});

const Student = mongoose.model('Student', studentSchema);
module.exports = Student; 