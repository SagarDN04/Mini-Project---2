const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const auth = require('../middleware/auth');
const isTeacher = require('../middleware/isTeacher');

// Get all events
router.get('/events', auth, async (req, res) => {
    try {
        const events = await Event.find()
            .populate('createdBy', 'name email')
            .populate('attendance.student', 'name email');
        res.json(events);
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Create new event (teachers only)
router.post('/events', [auth, isTeacher], async (req, res) => {
    try {
        const { title, description, date, endDate, attendanceRequired } = req.body;
        
        const event = new Event({
            title,
            description,
            date,
            endDate,
            attendanceRequired,
            createdBy: req.user.id
        });

        await event.save();
        
        const populatedEvent = await Event.findById(event._id)
            .populate('createdBy', 'name email');
        
        res.status(201).json(populatedEvent);
    } catch (error) {
        console.error('Error creating event:', error);
        res.status(500).json({ error: 'Failed to create event' });
    }
});

// Update event (teachers only)
router.patch('/events/:id', [auth, isTeacher], async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        
        const event = await Event.findOneAndUpdate(
            { _id: id, createdBy: req.user.id },
            { $set: updates },
            { new: true }
        ).populate('createdBy', 'name email')
         .populate('attendance.student', 'name email');

        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        res.json(event);
    } catch (error) {
        console.error('Error updating event:', error);
        res.status(500).json({ error: 'Failed to update event' });
    }
});

// Delete event (teachers only)
router.delete('/events/:id', [auth, isTeacher], async (req, res) => {
    try {
        const { id } = req.params;
        const event = await Event.findOneAndDelete({ _id: id, createdBy: req.user.id });
        
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        res.json({ message: 'Event deleted successfully' });
    } catch (error) {
        console.error('Error deleting event:', error);
        res.status(500).json({ error: 'Failed to delete event' });
    }
});

// Mark attendance (teachers only)
router.post('/events/:id/attendance', [auth, isTeacher], async (req, res) => {
    try {
        const { id } = req.params;
        const { attendance } = req.body;

        const event = await Event.findOne({ _id: id, createdBy: req.user.id });
        
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        if (!event.attendanceRequired) {
            return res.status(400).json({ error: 'Attendance not required for this event' });
        }

        event.attendance = attendance;
        await event.save();

        const populatedEvent = await Event.findById(event._id)
            .populate('createdBy', 'name email')
            .populate('attendance.student', 'name email');

        res.json(populatedEvent);
    } catch (error) {
        console.error('Error marking attendance:', error);
        res.status(500).json({ error: 'Failed to mark attendance' });
    }
});

// Get event attendance (teachers only)
router.get('/events/:id/attendance', [auth, isTeacher], async (req, res) => {
    try {
        const { id } = req.params;
        const event = await Event.findOne({ _id: id, createdBy: req.user.id })
            .populate('attendance.student', 'name email');

        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        res.json(event.attendance);
    } catch (error) {
        console.error('Error fetching attendance:', error);
        res.status(500).json({ error: 'Failed to fetch attendance' });
    }
});

module.exports = router; 