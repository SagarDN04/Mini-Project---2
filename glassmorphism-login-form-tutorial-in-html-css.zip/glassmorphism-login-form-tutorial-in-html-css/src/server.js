const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const { OAuth2Client } = require('google-auth-library');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campus_sync';
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Debug logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    console.log('Request Body:', req.body);
    next();
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..')));

// Import routes
const eventRoutes = require('./routes/events');

// MongoDB Connection with detailed logging
mongoose.connect(MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('Successfully connected to MongoDB.');
    console.log('Database:', MONGODB_URI);
})
.catch(err => {
    console.error('MongoDB connection error:', err);
    console.error('Connection string:', MONGODB_URI);
    process.exit(1); // Exit if cannot connect to database
});

// Log MongoDB events
mongoose.connection.on('error', err => {
    console.error('MongoDB error:', err);
});

mongoose.connection.on('disconnected', () => {
    console.log('MongoDB disconnected');
});

// User Schemas with validation
const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        trim: true,
        lowercase: true,
        validate: {
            validator: function(v) {
                return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
            },
            message: props => `${props.value} is not a valid email!`
        }
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [6, 'Password must be at least 6 characters']
    },
    role: {
        type: String,
        enum: ['student', 'teacher'],
        required: true
    },
    googleId: String,
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const Student = mongoose.model('Student', userSchema);
const Teacher = mongoose.model('Teacher', userSchema);

// Helper Functions
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '24h' }
  );
};

// Initialize Gemini with the API key
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Google Auth Route
app.post('/api/auth/google', async (req, res) => {
  try {
    const { credential, role } = req.body;
    const ticket = await googleClient.verifyIdToken({
      idToken: credential,
      audience: process.env.GOOGLE_CLIENT_ID
    });

    const payload = ticket.getPayload();
    const { email, name, sub: googleId } = payload;

    const UserModel = role === 'teacher' ? Teacher : Student;
    
    let user = await UserModel.findOne({ email });
    
    if (!user) {
      user = await UserModel.create({
        email,
        name,
        googleId,
        role
      });
    }

    const token = generateToken(user);
    res.json({ token, user: { name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    console.error('Google auth error:', error);
    res.status(401).json({ error: 'Authentication failed' });
  }
});

// Registration route with detailed error logging
app.post('/api/student/register', async (req, res) => {
    console.log('Starting registration process...');
    console.log('Request body:', req.body);
    
    try {
        const { name, email, password } = req.body;

        // Input validation
        if (!name || !email || !password) {
            console.log('Missing required fields:', { name: !!name, email: !!email, password: !!password });
            return res.status(400).json({
                error: 'Missing required fields',
                details: {
                    name: !name ? 'Name is required' : null,
                    email: !email ? 'Email is required' : null,
                    password: !password ? 'Password is required' : null
                }
            });
        }

        // Check for existing student
        const existingStudent = await Student.findOne({ email });
        if (existingStudent) {
            console.log('Email already registered:', email);
            return res.status(400).json({ 
                error: 'Email already registered',
                details: {
                    email: 'This email is already registered'
                }
            });
        }

        // Hash password
        console.log('Hashing password...');
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create student
        console.log('Creating new student...');
        const student = await Student.create({
            name,
            email,
            password: hashedPassword,
            role: 'student'
        });

        console.log('Student created successfully:', student._id);

        // Generate token
        const token = jwt.sign(
            { id: student._id, email: student.email, role: 'student' },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Send response
        res.status(201).json({
            success: true,
            token,
            user: {
                id: student._id,
                name: student.name,
                email: student.email,
                role: 'student'
            }
        });

    } catch (error) {
        console.error('Registration error details:', error);
        console.error('Error stack:', error.stack);

        if (error.code === 11000) {
            return res.status(400).json({
                error: 'Email already registered',
                details: {
                    email: 'This email is already registered'
                }
            });
        }

        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            console.log('Validation errors:', errors);
            return res.status(400).json({
                error: 'Validation error',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Registration failed',
            message: error.message
        });
    }
});

app.post('/api/teacher/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const teacher = await Teacher.findOne({ email });

    if (!teacher || !(await bcrypt.compare(password, teacher.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(teacher);
    res.json({ token, user: { name: teacher.name, email: teacher.email, role: 'teacher' } });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Protected Route Example
app.get('/api/user/profile', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const UserModel = decoded.role === 'teacher' ? Teacher : Student;
    const user = await UserModel.findById(decoded.id).select('-password');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    console.error('Profile error:', error);
    res.status(401).json({ error: 'Invalid token' });
  }
});

// Gemini Chat Route
app.post('/api/chat', async (req, res) => {
    try {
        const { message } = req.body;
        
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }

        console.log('Received chat request:', message);
        
        // Initialize Gemini model
        const model = genAI.getGenerativeModel({ model: "gemini-pro" });
        
        // Generate response
        console.log('Generating response...');
        const result = await model.generateContent({
            contents: [{ role: "user", parts: [{ text: message }] }],
        });
        
        console.log('Response received');
        const response = await result.response;
        const text = response.text();
        
        console.log('Sending response:', text);
        res.json({ response: text });
    } catch (error) {
        console.error('Gemini API error:', error);
        console.error('Error details:', {
            message: error.message,
            stack: error.stack,
            code: error.code
        });
        res.status(500).json({ 
            error: 'Failed to get response from AI',
            details: error.message 
        });
    }
});

// Use routes
app.use('/api', eventRoutes);

// Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 