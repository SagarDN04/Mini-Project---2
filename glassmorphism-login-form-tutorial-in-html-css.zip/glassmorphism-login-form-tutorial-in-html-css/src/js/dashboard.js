// Calendar functionality
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Calendar
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: [],
        editable: true,
        selectable: true,
        select: function(info) {
            const title = prompt('Enter event title:');
            if (title) {
                calendar.addEvent({
                    title: title,
                    start: info.start,
                    end: info.end,
                    allDay: info.allDay
                });
            }
            calendar.unselect();
        }
    });
    calendar.render();
});

// Task Management
class TaskManager {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        this.taskList = document.querySelector('.task-list');
        this.taskInput = document.querySelector('#taskInput');
        this.addTaskBtn = document.querySelector('#addTaskBtn');
        this.init();
    }

    init() {
        this.renderTasks();
        this.addTaskBtn.addEventListener('click', () => this.addTask());
        this.taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addTask();
        });
    }

    addTask() {
        const taskText = this.taskInput.value.trim();
        if (taskText) {
            const task = {
                id: Date.now(),
                text: taskText,
                completed: false,
                createdAt: new Date().toISOString()
            };
            this.tasks.push(task);
            this.saveTasks();
            this.renderTasks();
            this.taskInput.value = '';
        }
    }

    toggleTask(id) {
        const task = this.tasks.find(t => t.id === id);
        if (task) {
            task.completed = !task.completed;
            this.saveTasks();
            this.renderTasks();
        }
    }

    deleteTask(id) {
        this.tasks = this.tasks.filter(t => t.id !== id);
        this.saveTasks();
        this.renderTasks();
    }

    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    renderTasks() {
        this.taskList.innerHTML = '';
        this.tasks.forEach(task => {
            const li = document.createElement('li');
            li.className = 'task-item';
            li.innerHTML = `
                <input type="checkbox" ${task.completed ? 'checked' : ''}>
                <span style="text-decoration: ${task.completed ? 'line-through' : 'none'}">${task.text}</span>
                <button class="delete-task"><i class="fas fa-trash"></i></button>
            `;
            
            const checkbox = li.querySelector('input');
            checkbox.addEventListener('change', () => this.toggleTask(task.id));
            
            const deleteBtn = li.querySelector('.delete-task');
            deleteBtn.addEventListener('click', () => this.deleteTask(task.id));
            
            this.taskList.appendChild(li);
        });
    }
}

// Notifications System
class NotificationSystem {
    constructor() {
        this.notifications = JSON.parse(localStorage.getItem('notifications')) || [];
        this.notificationsList = document.querySelector('.notifications-list');
        this.init();
    }

    init() {
        this.renderNotifications();
        // Check for new notifications every minute
        setInterval(() => this.checkNewNotifications(), 60000);
    }

    addNotification(message, type = 'info') {
        const notification = {
            id: Date.now(),
            message,
            type,
            timestamp: new Date().toISOString(),
            read: false
        };
        this.notifications.unshift(notification);
        this.saveNotifications();
        this.renderNotifications();
    }

    markAsRead(id) {
        const notification = this.notifications.find(n => n.id === id);
        if (notification) {
            notification.read = true;
            this.saveNotifications();
            this.renderNotifications();
        }
    }

    saveNotifications() {
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
    }

    renderNotifications() {
        this.notificationsList.innerHTML = '';
        this.notifications.forEach(notification => {
            const div = document.createElement('div');
            div.className = `notification-item ${notification.read ? 'read' : 'unread'}`;
            div.innerHTML = `
                <p>${notification.message}</p>
                <span class="time">${new Date(notification.timestamp).toLocaleString()}</span>
            `;
            div.addEventListener('click', () => this.markAsRead(notification.id));
            this.notificationsList.appendChild(div);
        });
    }

    checkNewNotifications() {
        // Simulate receiving new notifications
        // In a real app, this would be connected to a backend
        const randomMessages = [
            'New assignment posted in Mathematics',
            'Upcoming exam schedule updated',
            'Campus event: Tech Talk tomorrow',
            'Library hours extended for finals week'
        ];
        
        if (Math.random() > 0.7) { // 30% chance of new notification
            this.addNotification(randomMessages[Math.floor(Math.random() * randomMessages.length)]);
        }
    }
}

// Chat System
class ChatSystem {
    constructor() {
        this.chatMessages = document.querySelector('.chat-messages');
        this.chatInput = document.querySelector('#chatInput');
        this.sendButton = document.querySelector('#sendMessage');
        this.init();
    }

    init() {
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
    }

    async sendMessage() {
        const message = this.chatInput.value.trim();
        if (!message) return;

        // Add user message to chat
        this.addMessageToChat('user', message);
        this.chatInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message })
            });

            if (!response.ok) {
                throw new Error('Failed to get response');
            }

            const data = await response.json();
            // Remove typing indicator and add bot response
            this.removeTypingIndicator();
            this.addMessageToChat('bot', data.response);
        } catch (error) {
            console.error('Chat error:', error);
            this.removeTypingIndicator();
            this.addMessageToChat('bot', 'Sorry, I encountered an error. Please try again.');
        }
    }

    addMessageToChat(type, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.innerHTML = `
            <p>${text}</p>
            <span class="time">${new Date().toLocaleTimeString()}</span>
        `;
        this.chatMessages.appendChild(messageDiv);
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }

    showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message bot typing-indicator';
        indicator.innerHTML = '<p>Typing...</p>';
        this.chatMessages.appendChild(indicator);
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }

    removeTypingIndicator() {
        const indicator = this.chatMessages.querySelector('.typing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }
}

// Initialize all systems
const taskManager = new TaskManager();
const notificationSystem = new NotificationSystem();
const chatSystem = new ChatSystem();

// Add some initial notifications
notificationSystem.addNotification('Welcome to Campus Sync!', 'info');
notificationSystem.addNotification('Your profile has been set up successfully', 'success'); 