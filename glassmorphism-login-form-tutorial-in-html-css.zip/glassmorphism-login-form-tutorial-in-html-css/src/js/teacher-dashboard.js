class TeacherDashboard {
    constructor() {
        this.calendar = null;
        this.events = [];
        this.currentEvent = null;
        this.init();
    }

    init() {
        this.initializeCalendar();
        this.setupEventListeners();
        this.loadEvents();
    }

    initializeCalendar() {
        const calendarEl = document.getElementById('calendar');
        this.calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: [],
            editable: true,
            selectable: true,
            select: (info) => this.handleDateSelect(info),
            eventClick: (info) => this.handleEventClick(info),
            eventDrop: (info) => this.handleEventDrop(info),
            eventResize: (info) => this.handleEventResize(info)
        });
        this.calendar.render();
    }

    setupEventListeners() {
        const eventForm = document.getElementById('eventForm');
        eventForm.addEventListener('submit', (e) => this.handleEventSubmit(e));
    }

    async loadEvents() {
        try {
            const response = await fetch('/api/events');
            if (!response.ok) throw new Error('Failed to load events');
            
            const events = await response.json();
            this.events = events;
            this.renderEvents();
            this.updateCalendarEvents();
        } catch (error) {
            console.error('Error loading events:', error);
            this.showError('Failed to load events');
        }
    }

    async handleEventSubmit(e) {
        e.preventDefault();
        
        const formData = {
            title: document.getElementById('eventTitle').value,
            description: document.getElementById('eventDescription').value,
            date: document.getElementById('eventDate').value,
            endDate: document.getElementById('eventEndDate').value,
            attendanceRequired: document.getElementById('attendanceRequired').checked
        };

        try {
            const response = await fetch('/api/events', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) throw new Error('Failed to create event');

            const event = await response.json();
            this.events.push(event);
            this.renderEvents();
            this.updateCalendarEvents();
            this.resetForm();
            this.showSuccess('Event created successfully');
        } catch (error) {
            console.error('Error creating event:', error);
            this.showError('Failed to create event');
        }
    }

    async handleEventClick(info) {
        const event = this.events.find(e => e._id === info.event.id);
        if (!event) return;

        this.currentEvent = event;
        
        const result = await Swal.fire({
            title: event.title,
            html: `
                <p>${event.description}</p>
                <p><strong>Date:</strong> ${new Date(event.date).toLocaleString()}</p>
                <p><strong>Attendance Required:</strong> ${event.attendanceRequired ? 'Yes' : 'No'}</p>
            `,
            showDenyButton: event.attendanceRequired,
            showCancelButton: true,
            confirmButtonText: 'Delete Event',
            denyButtonText: 'Mark Attendance',
            confirmButtonColor: '#dc3545',
            denyButtonColor: '#28a745'
        });

        if (result.isConfirmed) {
            this.deleteEvent(event._id);
        } else if (result.isDenied) {
            this.openAttendanceModal(event);
        }
    }

    async deleteEvent(eventId) {
        try {
            const response = await fetch(`/api/events/${eventId}`, {
                method: 'DELETE'
            });

            if (!response.ok) throw new Error('Failed to delete event');

            this.events = this.events.filter(e => e._id !== eventId);
            this.renderEvents();
            this.updateCalendarEvents();
            this.showSuccess('Event deleted successfully');
        } catch (error) {
            console.error('Error deleting event:', error);
            this.showError('Failed to delete event');
        }
    }

    async openAttendanceModal(event) {
        try {
            const response = await fetch('/api/students');
            if (!response.ok) throw new Error('Failed to load students');

            const students = await response.json();
            const modal = document.getElementById('attendanceModal');
            const titleEl = document.getElementById('modalEventTitle');
            const dateEl = document.getElementById('modalEventDate');
            const studentList = document.getElementById('studentList');

            titleEl.textContent = event.title;
            dateEl.textContent = new Date(event.date).toLocaleString();
            
            studentList.innerHTML = students.map(student => `
                <li class="student-item" data-student-id="${student._id}">
                    <span>${student.name}</span>
                    <div class="attendance-status">
                        <button class="status-btn present" onclick="markAttendance('${student._id}', 'present')">Present</button>
                        <button class="status-btn absent" onclick="markAttendance('${student._id}', 'absent')">Absent</button>
                        <button class="status-btn excused" onclick="markAttendance('${student._id}', 'excused')">Excused</button>
                    </div>
                </li>
            `).join('');

            modal.style.display = 'block';
        } catch (error) {
            console.error('Error loading students:', error);
            this.showError('Failed to load students');
        }
    }

    async saveAttendance() {
        if (!this.currentEvent) return;

        const attendance = [];
        const studentItems = document.querySelectorAll('.student-item');
        
        studentItems.forEach(item => {
            const studentId = item.dataset.studentId;
            const status = item.querySelector('.status-btn.active')?.dataset.status || 'absent';
            attendance.push({ student: studentId, status });
        });

        try {
            const response = await fetch(`/api/events/${this.currentEvent._id}/attendance`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ attendance })
            });

            if (!response.ok) throw new Error('Failed to save attendance');

            this.closeAttendanceModal();
            this.showSuccess('Attendance saved successfully');
        } catch (error) {
            console.error('Error saving attendance:', error);
            this.showError('Failed to save attendance');
        }
    }

    closeAttendanceModal() {
        const modal = document.getElementById('attendanceModal');
        modal.style.display = 'none';
        this.currentEvent = null;
    }

    renderEvents() {
        const eventList = document.querySelector('.event-list');
        const upcomingList = document.querySelector('.upcoming-events-list');
        
        // Sort events by date
        const sortedEvents = [...this.events].sort((a, b) => new Date(a.date) - new Date(b.date));
        
        // Render main event list
        eventList.innerHTML = sortedEvents.map(event => `
            <div class="event-item">
                <div class="event-header">
                    <span class="event-title">${event.title}</span>
                    <span class="event-date">${new Date(event.date).toLocaleDateString()}</span>
                </div>
                <div class="event-description">${event.description}</div>
                <div class="event-footer">
                    <span class="attendance-badge ${event.attendanceRequired ? 'attendance-required' : 'attendance-optional'}">
                        ${event.attendanceRequired ? 'Attendance Required' : 'Optional'}
                    </span>
                    <div class="event-actions">
                        ${event.attendanceRequired ? 
                            `<button class="btn btn-primary" onclick="dashboard.openAttendanceModal(${event._id})">
                                <i class="fas fa-user-check"></i> Attendance
                            </button>` : ''
                        }
                        <button class="btn btn-danger" onclick="dashboard.deleteEvent('${event._id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        // Render upcoming events
        const upcomingEvents = sortedEvents.filter(event => new Date(event.date) > new Date())
            .slice(0, 5);
        
        upcomingList.innerHTML = upcomingEvents.map(event => `
            <div class="event-item">
                <div class="event-title">${event.title}</div>
                <div class="event-date">${new Date(event.date).toLocaleString()}</div>
            </div>
        `).join('');
    }

    updateCalendarEvents() {
        this.calendar.removeAllEvents();
        this.calendar.addEventSource(this.events.map(event => ({
            id: event._id,
            title: event.title,
            start: event.date,
            end: event.endDate,
            color: event.attendanceRequired ? '#ff512f' : '#23a2f6'
        })));
    }

    resetForm() {
        document.getElementById('eventForm').reset();
    }

    showSuccess(message) {
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: message,
            timer: 2000,
            showConfirmButton: false
        });
    }

    showError(message) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: message
        });
    }

    handleDateSelect(info) {
        document.getElementById('eventDate').value = info.startStr;
        document.getElementById('eventEndDate').value = info.endStr;
        document.getElementById('eventTitle').focus();
    }

    async handleEventDrop(info) {
        try {
            const eventId = info.event.id;
            const response = await fetch(`/api/events/${eventId}`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    date: info.event.start,
                    endDate: info.event.end || info.event.start
                })
            });

            if (!response.ok) {
                info.revert();
                throw new Error('Failed to update event');
            }

            const updatedEvent = await response.json();
            this.events = this.events.map(e => e._id === eventId ? updatedEvent : e);
            this.renderEvents();
        } catch (error) {
            console.error('Error updating event:', error);
            this.showError('Failed to update event');
        }
    }

    handleEventResize(info) {
        this.handleEventDrop(info);
    }
}

// Initialize the dashboard
const dashboard = new TeacherDashboard();

// Global functions for the attendance modal
window.markAttendance = function(studentId, status) {
    const studentItem = document.querySelector(`[data-student-id="${studentId}"]`);
    const buttons = studentItem.querySelectorAll('.status-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    const selectedBtn = studentItem.querySelector(`.status-btn.${status}`);
    selectedBtn.classList.add('active');
};

window.saveAttendance = function() {
    dashboard.saveAttendance();
};

window.closeAttendanceModal = function() {
    dashboard.closeAttendanceModal();
}; 