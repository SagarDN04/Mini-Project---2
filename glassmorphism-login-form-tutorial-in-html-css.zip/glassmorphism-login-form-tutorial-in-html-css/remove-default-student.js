const mongoose = require('mongoose');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campus-sync';

async function removeDefaultStudent() {
    try {
        // Connect to MongoDB
        await mongoose.connect(MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('Connected to MongoDB');

        // Find and remove the default student
        const result = await mongoose.model('Student').deleteOne({
            email: 'student@campussync.com'
        });

        if (result.deletedCount > 0) {
            console.log('Default student account removed successfully');
        } else {
            console.log('Default student account not found in database');
        }

        // Close the connection
        await mongoose.connection.close();
        console.log('MongoDB connection closed');
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

removeDefaultStudent(); 