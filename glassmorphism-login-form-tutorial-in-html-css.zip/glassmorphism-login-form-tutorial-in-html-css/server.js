const express = require('express');
const path = require('path');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const Teacher = require('./src/models/Teacher');
const Event = require('./src/models/Event');
const Student = require('./src/models/Student');
const bcrypt = require('bcrypt');

const app = express();
const PORT = process.env.PORT || 3000;

// Enhanced error handling middleware
const errorHandler = (err, req, res, next) => {
    console.error('Error:', {
        message: err.message,
        stack: err.stack,
        path: req.path,
        method: req.method,
        body: req.body
    });
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        path: req.path,
        timestamp: new Date().toISOString()
    });
};

// Request logging middleware
const requestLogger = (req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`, {
        body: req.body,
        query: req.query,
        params: req.params
    });
    next();
};

// Response logging middleware
const responseLogger = (req, res, next) => {
    const originalJson = res.json;
    res.json = function(data) {
        console.log(`${new Date().toISOString()} - Response for ${req.method} ${req.path}:`, data);
        return originalJson.call(this, data);
    };
    next();
};

// MongoDB connection with enhanced error handling
mongoose.connect('mongodb://localhost:27017/campus_sync', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(requestLogger);
app.use(responseLogger);

// Serve static files
app.use(express.static(path.join(__dirname, 'src')));
app.use('/assets', express.static(path.join(__dirname, 'src/assets')));
app.use('/js', express.static(path.join(__dirname, 'src/js')));

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Serve HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});

app.get('/student-login', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student-login.html'));
});

app.get('/teacher-login', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'teacher-login.html'));
});

app.get('/teacher-register', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'teacher-register.html'));
});

app.get('/student-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student-dashboard.html'));
});

app.get('/teacher-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'teacher-dashboard.html'));
});

app.get('/student-register', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student-register.html'));
});

// JWT secret (use environment variable in production)
const JWT_SECRET = 'your-secret-key';

// JWT verification with detailed error handling
const auth = (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ 
                error: 'Authentication required',
                details: 'No token provided'
            });
        }
        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            req.user = decoded;
            next();
        } catch (err) {
            console.error('JWT Verification Error:', err);
            return res.status(401).json({ 
                error: 'Invalid token',
                details: err.message
            });
        }
    } catch (error) {
        next(error);
    }
};

// API Routes
// Teacher login endpoint
app.post('/api/auth/teacher/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Validate input
        if (!email || !password) {
            return res.status(400).json({ 
                error: 'Missing credentials',
                details: {
                    email: !email ? 'Email is required' : null,
                    password: !password ? 'Password is required' : null
                }
            });
        }

        // Find teacher
        const teacher = await Teacher.findOne({ email });
        if (!teacher) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, teacher.password);
        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        // Generate token
        const token = jwt.sign(
            { 
                id: teacher._id, 
                email: teacher.email, 
                role: 'teacher',
                department: teacher.department 
            },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Send response
        res.json({
            success: true,
            token,
            user: {
                id: teacher._id,
                name: teacher.name,
                email: teacher.email,
                department: teacher.department,
                role: 'teacher'
            }
        });
    } catch (error) {
        console.error('Login Error:', error);
        res.status(500).json({ 
            error: 'Server error',
            message: 'An error occurred during login. Please try again.'
        });
    }
});

// Teacher registration endpoint
app.post('/api/teacher/register', async (req, res) => {
    console.log('Starting teacher registration process...');
    console.log('Request body:', req.body);
    
    try {
        const { name, email, password, department } = req.body;

        // Input validation
        if (!name || !email || !password || !department) {
            console.log('Missing required fields:', { 
                name: !!name, 
                email: !!email, 
                password: !!password,
                department: !!department
            });
            return res.status(400).json({
                error: 'Missing required fields',
                details: {
                    name: !name ? 'Name is required' : null,
                    email: !email ? 'Email is required' : null,
                    password: !password ? 'Password is required' : null,
                    department: !department ? 'Department is required' : null
                }
            });
        }

        // Check for existing teacher
        const existingTeacher = await Teacher.findOne({ email });
        if (existingTeacher) {
            console.log('Teacher already exists:', existingTeacher.email);
            return res.status(400).json({ 
                error: 'Teacher already exists',
                details: {
                    email: 'Email already registered'
                }
            });
        }

        // Hash password
        console.log('Hashing password...');
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create teacher
        console.log('Creating new teacher...');
        const teacher = await Teacher.create({
            name,
            email,
            password: hashedPassword,
            department
        });

        console.log('Teacher created successfully:', teacher._id);

        // Generate token
        const token = jwt.sign(
            { id: teacher._id, email: teacher.email, role: 'teacher' },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Send response
        res.status(201).json({
            success: true,
            token,
            user: {
                id: teacher._id,
                name: teacher.name,
                email: teacher.email,
                role: 'teacher'
            }
        });

    } catch (error) {
        console.error('Registration error details:', error);
        console.error('Error stack:', error.stack);

        if (error.code === 11000) {
            return res.status(400).json({
                error: 'Teacher already exists',
                details: {
                    email: 'Email already registered'
                }
            });
        }

        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            console.log('Validation errors:', errors);
            return res.status(400).json({
                error: 'Validation error',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Registration failed',
            message: error.message
        });
    }
});

// Event Management Routes
// Create new event
app.post('/api/events', auth, async (req, res) => {
    try {
        console.log('Received event creation request:', req.body);
        
        const { title, description, date, endDate, attendanceRequired } = req.body;
        
        if (!title || !description || !date || !endDate) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const event = new Event({
            title,
            description,
            date: new Date(date),
            endDate: new Date(endDate),
            createdBy: req.user.id,
            attendanceRequired: attendanceRequired || false
        });

        console.log('Creating event:', event);
        await event.save();
        console.log('Event created successfully:', event);

        res.status(201).json(event);
    } catch (error) {
        console.error('Event Creation Error:', error);
        res.status(500).json({ 
            error: 'Failed to create event',
            details: error.message 
        });
    }
});

// Get all events
app.get('/api/events', auth, async (req, res) => {
    try {
        const events = await Event.find()
            .populate('createdBy', 'name email')
            .sort({ date: 1 });
        res.json(events);
    } catch (error) {
        console.error('Event Fetch Error:', error);
        res.status(500).json({ error: 'Failed to fetch events' });
    }
});

// Get single event
app.get('/api/events/:id', auth, async (req, res) => {
    try {
        const event = await Event.findById(req.params.id)
            .populate('createdBy', 'name email')
            .populate('attendance.student', 'name email');
        
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }
        
        res.json(event);
    } catch (error) {
        console.error('Event Fetch Error:', error);
        res.status(500).json({ error: 'Failed to fetch event' });
    }
});

// Update event
app.put('/api/events/:id', auth, async (req, res) => {
    try {
        const { title, description, date, endDate, attendanceRequired } = req.body;
        
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        // Check if user is the creator of the event
        if (event.createdBy.toString() !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to update this event' });
        }

        event.title = title;
        event.description = description;
        event.date = date;
        event.endDate = endDate;
        event.attendanceRequired = attendanceRequired;

        await event.save();
        res.json(event);
    } catch (error) {
        console.error('Event Update Error:', error);
        res.status(500).json({ error: 'Failed to update event' });
    }
});

// Delete event
app.delete('/api/events/:id', auth, async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        // Check if user is the creator of the event
        if (event.createdBy.toString() !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to delete this event' });
        }

        await Event.findByIdAndDelete(req.params.id);
        res.json({ message: 'Event deleted successfully' });
    } catch (error) {
        console.error('Event Delete Error:', error);
        res.status(500).json({ error: 'Failed to delete event' });
    }
});

// Update attendance
app.post('/api/events/:id/attendance', auth, async (req, res) => {
    try {
        const { attendance } = req.body;
        
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        // Check if user is the creator of the event
        if (event.createdBy.toString() !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized to update attendance' });
        }

        // Update attendance records
        event.attendance = attendance.map(record => ({
            student: record.studentId,
            status: record.status,
            timestamp: new Date()
        }));

        await event.save();
        
        // Return updated event with populated data
        const updatedEvent = await Event.findById(event._id)
            .populate('attendance.student', 'name prn');
            
        res.json(updatedEvent);
    } catch (error) {
        console.error('Attendance Update Error:', error);
        res.status(500).json({ error: 'Failed to update attendance' });
    }
});

// Student Management Routes
app.post('/api/students', auth, async (req, res) => {
    try {
        const { prn, name, department, graduationYear, email } = req.body;

        // Check if student already exists
        const existingStudent = await Student.findOne({ $or: [{ prn }, { email }] });
        if (existingStudent) {
            return res.status(400).json({ error: 'Student with this PRN or email already exists' });
        }

        const student = new Student({
            prn,
            name,
            department,
            graduationYear,
            email
        });

        await student.save();
        res.status(201).json(student);
    } catch (error) {
        console.error('Student Creation Error:', error);
        res.status(500).json({ error: 'Failed to create student' });
    }
});

// Get all students
app.get('/api/students', auth, async (req, res) => {
    try {
        const students = await Student.find().sort({ name: 1 });
        res.json(students);
    } catch (error) {
        console.error('Student Fetch Error:', error);
        res.status(500).json({ error: 'Failed to fetch students' });
    }
});

// Get students by department
app.get('/api/students/department/:dept', auth, async (req, res) => {
    try {
        const students = await Student.find({ department: req.params.dept }).sort({ name: 1 });
        res.json(students);
    } catch (error) {
        console.error('Student Fetch Error:', error);
        res.status(500).json({ error: 'Failed to fetch students' });
    }
});

// Update student
app.put('/api/students/:id', auth, async (req, res) => {
    try {
        const { prn, name, department, graduationYear, email } = req.body;
        
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        // Check if PRN or email is being changed and if it conflicts with existing students
        if (prn !== student.prn || email !== student.email) {
            const existingStudent = await Student.findOne({
                _id: { $ne: req.params.id },
                $or: [{ prn }, { email }]
            });
            if (existingStudent) {
                return res.status(400).json({ error: 'PRN or email already in use' });
            }
        }

        student.prn = prn;
        student.name = name;
        student.department = department;
        student.graduationYear = graduationYear;
        student.email = email;

        await student.save();
        res.json(student);
    } catch (error) {
        console.error('Student Update Error:', error);
        res.status(500).json({ error: 'Failed to update student' });
    }
});

// Delete student
app.delete('/api/students/:id', auth, async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ error: 'Student not found' });
        }

        await student.remove();
        res.json({ message: 'Student deleted successfully' });
    } catch (error) {
        console.error('Student Delete Error:', error);
        res.status(500).json({ error: 'Failed to delete student' });
    }
});

// Teacher Profile Routes
app.get('/api/teacher/profile', auth, async (req, res) => {
    try {
        const teacher = await Teacher.findById(req.user.id).select('-password');
        if (!teacher) {
            return res.status(404).json({ error: 'Teacher not found' });
        }
        res.json(teacher);
    } catch (error) {
        console.error('Profile Fetch Error:', error);
        res.status(500).json({ error: 'Failed to fetch profile' });
    }
});

app.put('/api/teacher/profile', auth, async (req, res) => {
    try {
        const { name, email, department } = req.body;
        
        // Check if email is being changed and if it conflicts with existing teachers
        if (email) {
            const existingTeacher = await Teacher.findOne({
                _id: { $ne: req.user.id },
                email
            });
            if (existingTeacher) {
                return res.status(400).json({ error: 'Email already in use' });
            }
        }

        const teacher = await Teacher.findByIdAndUpdate(
            req.user.id,
            { 
                $set: { 
                    name: name || undefined,
                    email: email || undefined,
                    department: department || undefined
                }
            },
            { new: true, runValidators: true }
        ).select('-password');

        if (!teacher) {
            return res.status(404).json({ error: 'Teacher not found' });
        }

        res.json(teacher);
    } catch (error) {
        console.error('Profile Update Error:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});

app.put('/api/teacher/password', auth, async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        
        const teacher = await Teacher.findById(req.user.id);
        if (!teacher) {
            return res.status(404).json({ error: 'Teacher not found' });
        }

        // Verify current password
        const isMatch = await teacher.verifyPassword(currentPassword);
        if (!isMatch) {
            return res.status(401).json({ error: 'Current password is incorrect' });
        }

        // Update password
        teacher.password = newPassword;
        await teacher.save();

        res.json({ message: 'Password updated successfully' });
    } catch (error) {
        console.error('Password Update Error:', error);
        res.status(500).json({ error: 'Failed to update password' });
    }
});

// Student registration endpoint
app.post('/api/auth/student/register', async (req, res) => {
    console.log('Starting student registration process...');
    console.log('Request body:', req.body);
    
    try {
        const { name, email, password, prn, department, graduationYear } = req.body;

        // Input validation
        if (!name || !email || !password || !prn || !department || !graduationYear) {
            console.log('Missing required fields:', { 
                name: !!name, 
                email: !!email, 
                password: !!password,
                prn: !!prn,
                department: !!department,
                graduationYear: !!graduationYear
            });
            return res.status(400).json({
                error: 'Missing required fields',
                details: {
                    name: !name ? 'Name is required' : null,
                    email: !email ? 'Email is required' : null,
                    password: !password ? 'Password is required' : null,
                    prn: !prn ? 'PRN is required' : null,
                    department: !department ? 'Department is required' : null,
                    graduationYear: !graduationYear ? 'Graduation year is required' : null
                }
            });
        }

        // Validate PRN format (10 digits)
        if (!/^\d{10}$/.test(prn)) {
            return res.status(400).json({
                error: 'Invalid PRN format',
                details: {
                    prn: 'PRN must be exactly 10 digits'
                }
            });
        }

        // Validate department
        const validDepartments = [
            'CSE',
            'AIML',
            'DS',
            'MECHANICAL',
            'ENTC',
            'ELECTRICAL',
            'BIOTECH',
            'CIVIL',
            'ENVIRONMENT'
        ];
        
        if (!validDepartments.includes(department)) {
            return res.status(400).json({
                error: 'Invalid department',
                details: {
                    department: 'Please select a valid department from the list'
                }
            });
        }

        // Check for existing student
        const existingStudent = await Student.findOne({ $or: [{ email }, { prn }] });
        if (existingStudent) {
            console.log('Student already exists:', existingStudent.email);
            return res.status(400).json({ 
                error: 'Student already exists',
                details: {
                    email: existingStudent.email === email ? 'Email already registered' : null,
                    prn: existingStudent.prn === prn ? 'PRN already registered' : null
                }
            });
        }

        // Hash password
        console.log('Hashing password...');
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create student
        console.log('Creating new student...');
        const student = await Student.create({
            name,
            email,
            password: hashedPassword,
            prn,
            department,
            graduationYear
        });

        console.log('Student created successfully:', student._id);

        // Generate token
        const token = jwt.sign(
            { id: student._id, email: student.email, role: 'student' },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        // Send response
        res.status(201).json({
            success: true,
            token,
            user: {
                id: student._id,
                name: student.name,
                email: student.email,
                prn: student.prn,
                department: student.department,
                graduationYear: student.graduationYear
            }
        });

    } catch (error) {
        console.error('Registration error details:', error);
        console.error('Error stack:', error.stack);

        if (error.code === 11000) {
            return res.status(400).json({
                error: 'Student already exists',
                details: {
                    email: 'Email already registered',
                    prn: 'PRN already registered'
                }
            });
        }

        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            console.log('Validation errors:', errors);
            return res.status(400).json({
                error: 'Validation error',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Registration failed',
            message: error.message
        });
    }
});

// Get recent attendance
app.get('/api/attendance/recent', auth, async (req, res) => {
    try {
        const events = await Event.find({ createdBy: req.user.id })
            .sort({ date: -1 })
            .limit(5)
            .populate('attendance.student', 'name prn');

        const attendanceData = events.map(event => ({
            _id: event._id,
            event: {
                title: event.title,
                date: event.date
            },
            studentsPresent: event.attendance.filter(a => a.status === 'present').length,
            totalStudents: event.attendance.length
        }));

        res.json(attendanceData);
    } catch (error) {
        console.error('Error fetching recent attendance:', error);
        res.status(500).json({ error: 'Failed to fetch attendance data' });
    }
});

// Get teacher stats
app.get('/api/teacher/stats', auth, async (req, res) => {
    try {
        const events = await Event.find({ createdBy: req.user.id });
        const students = await Student.find();
        
        // Calculate stats
        const totalEvents = events.length;
        let totalAttendance = 0;
        let totalPossibleAttendance = 0;
        
        events.forEach(event => {
            const presentCount = event.attendance.filter(a => a.status === 'present').length;
            totalAttendance += presentCount;
            totalPossibleAttendance += event.attendance.length;
        });

        const averageAttendance = totalPossibleAttendance > 0 
            ? Math.round((totalAttendance / totalPossibleAttendance) * 100) 
            : 0;

        const activeStudents = students.length;

        res.json({
            totalEvents,
            averageAttendance,
            activeStudents
        });
    } catch (error) {
        console.error('Error fetching teacher stats:', error);
        res.status(500).json({ error: 'Failed to fetch statistics' });
    }
});

// Get students for event
app.get('/api/events/:id/students', auth, async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        const students = await Student.find();
        const studentsWithAttendance = students.map(student => {
            const attendanceRecord = event.attendance?.find(a => 
                a.student && student._id && a.student.toString() === student._id.toString()
            );
            return {
                _id: student._id,
                name: student.name,
                prn: student.prn || 'N/A',
                status: attendanceRecord ? attendanceRecord.status : null
            };
        });

        res.json(studentsWithAttendance);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).json({ error: 'Failed to fetch students' });
    }
});

// Get attendance report
app.get('/api/events/:id/attendance/report', auth, async (req, res) => {
    try {
        const event = await Event.findById(req.params.id)
            .populate('attendance.student', 'name prn department');
        
        if (!event) {
            return res.status(404).json({ error: 'Event not found' });
        }

        const report = {
            eventTitle: event.title,
            eventDate: event.date,
            totalStudents: event.attendance.length,
            presentCount: event.attendance.filter(a => a.status === 'present').length,
            absentCount: event.attendance.filter(a => a.status === 'absent').length,
            attendanceByDepartment: {},
            studentDetails: event.attendance.map(a => ({
                name: a.student.name,
                prn: a.student.prn,
                department: a.student.department,
                status: a.status,
                timestamp: a.timestamp
            }))
        };

        // Calculate department-wise attendance
        event.attendance.forEach(a => {
            const dept = a.student.department;
            if (!report.attendanceByDepartment[dept]) {
                report.attendanceByDepartment[dept] = {
                    total: 0,
                    present: 0
                };
            }
            report.attendanceByDepartment[dept].total++;
            if (a.status === 'present') {
                report.attendanceByDepartment[dept].present++;
            }
        });

        res.json(report);
    } catch (error) {
        console.error('Error generating attendance report:', error);
        res.status(500).json({ error: 'Failed to generate attendance report' });
    }
});

// Get all attendance records
app.get('/api/attendance/all', auth, async (req, res) => {
    try {
        const events = await Event.find({ createdBy: req.user.id })
            .sort({ date: -1 })
            .populate('attendance.student', 'name prn');

        const attendanceData = events.map(event => ({
            _id: event._id,
            event: {
                title: event.title,
                date: event.date
            },
            studentsPresent: event.attendance.filter(a => a.status === 'present').length,
            totalStudents: event.attendance.length
        }));

        res.json(attendanceData);
    } catch (error) {
        console.error('Error fetching attendance records:', error);
        res.status(500).json({ error: 'Failed to fetch attendance records' });
    }
});

// Get attendance report
app.get('/api/reports/attendance', auth, async (req, res) => {
    try {
        const events = await Event.find({ createdBy: req.user.id });
        const students = await Student.find();
        
        let totalAttendance = 0;
        let totalPossibleAttendance = 0;
        
        events.forEach(event => {
            const presentCount = event.attendance.filter(a => a.status === 'present').length;
            totalAttendance += presentCount;
            totalPossibleAttendance += event.attendance.length;
        });

        const report = {
            totalEvents: events.length,
            averageAttendance: totalPossibleAttendance > 0 
                ? Math.round((totalAttendance / totalPossibleAttendance) * 100) 
                : 0,
            activeStudents: students.length,
            monthlyStats: await getMonthlyAttendanceStats(events)
        };

        res.json(report);
    } catch (error) {
        console.error('Error generating attendance report:', error);
        res.status(500).json({ error: 'Failed to generate attendance report' });
    }
});

// Get events report
app.get('/api/reports/events', auth, async (req, res) => {
    try {
        const now = new Date();
        const events = await Event.find({ createdBy: req.user.id });
        
        const report = {
            totalEvents: events.length,
            upcomingEvents: events.filter(e => new Date(e.date) > now).length,
            pastEvents: events.filter(e => new Date(e.date) <= now).length,
            eventsByMonth: await getEventsByMonth(events),
            popularTimes: await getPopularEventTimes(events)
        };

        res.json(report);
    } catch (error) {
        console.error('Error generating events report:', error);
        res.status(500).json({ error: 'Failed to generate events report' });
    }
});

// Get department-wise report
app.get('/api/reports/department', auth, async (req, res) => {
    try {
        const events = await Event.find({ createdBy: req.user.id })
            .populate('attendance.student', 'department');
        const students = await Student.find();
        
        const departmentStats = {};
        
        // Initialize department stats
        students.forEach(student => {
            if (!departmentStats[student.department]) {
                departmentStats[student.department] = {
                    totalStudents: 0,
                    totalAttendance: 0,
                    totalPossibleAttendance: 0
                };
            }
            departmentStats[student.department].totalStudents++;
        });

        // Calculate attendance by department
        events.forEach(event => {
            event.attendance.forEach(record => {
                const dept = record.student.department;
                if (departmentStats[dept]) {
                    departmentStats[dept].totalPossibleAttendance++;
                    if (record.status === 'present') {
                        departmentStats[dept].totalAttendance++;
                    }
                }
            });
        });

        // Calculate averages
        Object.keys(departmentStats).forEach(dept => {
            const stats = departmentStats[dept];
            stats.averageAttendance = stats.totalPossibleAttendance > 0
                ? Math.round((stats.totalAttendance / stats.totalPossibleAttendance) * 100)
                : 0;
        });

        res.json({
            departmentStats,
            totalDepartments: Object.keys(departmentStats).length
        });
    } catch (error) {
        console.error('Error generating department report:', error);
        res.status(500).json({ error: 'Failed to generate department report' });
    }
});

// Helper functions for reports
async function getMonthlyAttendanceStats(events) {
    const monthlyStats = {};
    events.forEach(event => {
        const month = new Date(event.date).toLocaleString('default', { month: 'long' });
        if (!monthlyStats[month]) {
            monthlyStats[month] = {
                total: 0,
                present: 0
            };
        }
        const presentCount = event.attendance.filter(a => a.status === 'present').length;
        monthlyStats[month].total += event.attendance.length;
        monthlyStats[month].present += presentCount;
    });
    return monthlyStats;
}

async function getEventsByMonth(events) {
    const eventsByMonth = {};
    events.forEach(event => {
        const month = new Date(event.date).toLocaleString('default', { month: 'long' });
        if (!eventsByMonth[month]) {
            eventsByMonth[month] = 0;
        }
        eventsByMonth[month]++;
    });
    return eventsByMonth;
}

async function getPopularEventTimes(events) {
    const timeSlots = {};
    events.forEach(event => {
        const hour = new Date(event.date).getHours();
        const timeSlot = `${hour}:00`;
        if (!timeSlots[timeSlot]) {
            timeSlots[timeSlot] = 0;
        }
        timeSlots[timeSlot]++;
    });
    return timeSlots;
}

// Error handling middleware should be last
app.use(errorHandler);

// Start server with enhanced error handling
const server = app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
}).on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use. Please try a different port.`);
        process.exit(1);
    } else {
        console.error('Server error:', err);
        process.exit(1);
    }
}); 